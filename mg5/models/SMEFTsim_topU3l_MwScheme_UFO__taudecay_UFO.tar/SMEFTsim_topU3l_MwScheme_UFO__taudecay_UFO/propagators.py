
# This file was automatically created by The UFO_usermod   

from object_library import all_propagators, Propagator
S = Propagator(name = 'S',
               numerator = '1',
               denominator = '(P(\'mu\', id) * P(\'mu\', id) - Mass(id) * Mass(id) + complex(0,1) * Mass(id) * Width(id))')


F = Propagator(name = 'F',
               numerator = '(Gamma(\'mu\', 1, 2) * P(\'mu\', id) + Mass(id) * Identity(1, 2))',
               denominator = '(P(\'mu\', id) * P(\'mu\', id) - Mass(id) * Mass(id) + complex(0,1) * Mass(id) * Width(id))')


V1 = Propagator(name = 'V1',
                numerator = '(- Metric(1, 2) + Metric(1,\'mu\')* P(\'mu\', id) * P(2, id) / Mass(id)**2) ',
                denominator = '(P(\'mu\', id) * P(\'mu\', id) - Mass(id) * Mass(id) + complex(0,1) * Mass(id) * Width(id))')


V2 = Propagator(name = 'V2',
                numerator = '- Metric(1, 2)',
                denominator = 'P(\'mu\', id) * P(\'mu\', id)')


Z1 = Propagator(name = 'Z1',
                numerator = '-(- Metric(1, 2) + Metric(1,\'mu\')* P(\'mu\', id) * P(2, id) / Mass(id)**2) * complex(0,1) * Mass(id) * dWZ',
                denominator = '(P(\'mu\', id) * P(\'mu\', id) - Mass(id) * Mass(id) + complex(0,1) * Mass(id) * Width(id))**2')


W1 = Propagator(name = 'W1',
                numerator = '-(- Metric(1, 2) + Metric(1,\'mu\')* P(\'mu\', id) * P(2, id) / Mass(id)**2) * complex(0,1) * Mass(id) * dWW',
                denominator = '(P(\'mu\', id) * P(\'mu\', id) - Mass(id) * Mass(id) + complex(0,1) * Mass(id) * Width(id))**2')


H1 = Propagator(name = 'H1',
                numerator = '- complex(0,1) * Mass(id) * dWH',
                denominator = '(P(\'mu\', id) * P(\'mu\', id) - Mass(id) * Mass(id) + complex(0,1) * Mass(id) * Width(id))**2')


T1 = Propagator(name = 'T1',
                numerator = '-(Gamma(\'mu\', 1, 2) * P(\'mu\', id) + Mass(id) * Identity(1, 2))* complex(0,1) * Mass(id) * dWT',
                denominator = '(P(\'mu\', id) * P(\'mu\', id) - Mass(id) * Mass(id) + complex(0,1) * Mass(id) * Width(id))**2')

