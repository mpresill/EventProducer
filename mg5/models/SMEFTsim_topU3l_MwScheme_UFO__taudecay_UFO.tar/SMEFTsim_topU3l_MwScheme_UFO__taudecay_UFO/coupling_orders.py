
# This file was automatically created by The UFO_usermod        
from object_library import all_orders, CouplingOrder
QCD = CouplingOrder(expansion_order = 99,
                    hierarchy = 1,
                    name = 'QCD',
                    perturbative_expansion = 0)


QED = CouplingOrder(expansion_order = 99,
                    hierarchy = 1,
                    name = 'QED',
                    perturbative_expansion = 0)


SMHLOOP = CouplingOrder(expansion_order = 99,
                        hierarchy = 99,
                        name = 'SMHLOOP',
                        perturbative_expansion = 0)


NP = CouplingOrder(expansion_order = 99,
                   hierarchy = 99,
                   name = 'NP',
                   perturbative_expansion = 0)


NPshifts = CouplingOrder(expansion_order = 99,
                         hierarchy = 99,
                         name = 'NPshifts',
                         perturbative_expansion = 0)


NPprop = CouplingOrder(expansion_order = 0,
                       hierarchy = 99,
                       name = 'NPprop',
                       perturbative_expansion = 0)


NPcpv = CouplingOrder(expansion_order = 99,
                      hierarchy = 99,
                      name = 'NPcpv',
                      perturbative_expansion = 0)


NPcbb = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcbb',
                      perturbative_expansion = 0)


NPcbB = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcbB',
                      perturbative_expansion = 0)


NPcbBB = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcbBB',
                       perturbative_expansion = 0)


NPcbd1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcbd1',
                       perturbative_expansion = 0)


NPcbd8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcbd8',
                       perturbative_expansion = 0)


NPcbe = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcbe',
                      perturbative_expansion = 0)


NPcbG = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcbG',
                      perturbative_expansion = 0)


NPcbH = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcbH',
                      perturbative_expansion = 0)


NPcbj1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcbj1',
                       perturbative_expansion = 0)


NPcbj8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcbj8',
                       perturbative_expansion = 0)


NPcbl = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcbl',
                      perturbative_expansion = 0)


NPcbu1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcbu1',
                       perturbative_expansion = 0)


NPcbu8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcbu8',
                       perturbative_expansion = 0)


NPcbW = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcbW',
                      perturbative_expansion = 0)


NPcdB = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcdB',
                      perturbative_expansion = 0)


NPcdd1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcdd1',
                       perturbative_expansion = 0)


NPcdd8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcdd8',
                       perturbative_expansion = 0)


NPcdG = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcdG',
                      perturbative_expansion = 0)


NPcdH = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcdH',
                      perturbative_expansion = 0)


NPcdW = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcdW',
                      perturbative_expansion = 0)


NPceB = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPceB',
                      perturbative_expansion = 0)


NPced = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPced',
                      perturbative_expansion = 0)


NPcee = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcee',
                      perturbative_expansion = 0)


NPceH = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPceH',
                      perturbative_expansion = 0)


NPceu = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPceu',
                      perturbative_expansion = 0)


NPceW = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPceW',
                      perturbative_expansion = 0)


NPcG = CouplingOrder(expansion_order = 99,
                     hierarchy = 1,
                     name = 'NPcG',
                     perturbative_expansion = 0)


NPcGtil = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcGtil',
                        perturbative_expansion = 0)


NPcH = CouplingOrder(expansion_order = 99,
                     hierarchy = 1,
                     name = 'NPcH',
                     perturbative_expansion = 0)


NPcHB = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcHB',
                      perturbative_expansion = 0)


NPcHbox = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcHbox',
                        perturbative_expansion = 0)


NPcHbq = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcHbq',
                       perturbative_expansion = 0)


NPcHBtil = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcHBtil',
                         perturbative_expansion = 0)


NPcHd = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcHd',
                      perturbative_expansion = 0)


NPcHDD = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcHDD',
                       perturbative_expansion = 0)


NPcHe = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcHe',
                      perturbative_expansion = 0)


NPcHG = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcHG',
                      perturbative_expansion = 0)


NPcHGtil = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcHGtil',
                         perturbative_expansion = 0)


NPcHj1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcHj1',
                       perturbative_expansion = 0)


NPcHj3 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcHj3',
                       perturbative_expansion = 0)


NPcHl1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcHl1',
                       perturbative_expansion = 0)


NPcHl3 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcHl3',
                       perturbative_expansion = 0)


NPcHQ1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcHQ1',
                       perturbative_expansion = 0)


NPcHQ3 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcHQ3',
                       perturbative_expansion = 0)


NPcHt = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcHt',
                      perturbative_expansion = 0)


NPcHtb = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcHtb',
                       perturbative_expansion = 0)


NPcHu = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcHu',
                      perturbative_expansion = 0)


NPcHud = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcHud',
                       perturbative_expansion = 0)


NPcHW = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcHW',
                      perturbative_expansion = 0)


NPcHWB = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcHWB',
                       perturbative_expansion = 0)


NPcHWBtil = CouplingOrder(expansion_order = 99,
                          hierarchy = 1,
                          name = 'NPcHWBtil',
                          perturbative_expansion = 0)


NPcHWtil = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcHWtil',
                         perturbative_expansion = 0)


NPcjd1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcjd1',
                       perturbative_expansion = 0)


NPcjd8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcjd8',
                       perturbative_expansion = 0)


NPcje = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcje',
                      perturbative_expansion = 0)


NPcjj11 = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcjj11',
                        perturbative_expansion = 0)


NPcjj18 = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcjj18',
                        perturbative_expansion = 0)


NPcjj31 = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcjj31',
                        perturbative_expansion = 0)


NPcjj38 = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcjj38',
                        perturbative_expansion = 0)


NPcjQbd1 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcjQbd1',
                         perturbative_expansion = 0)


NPcjQbd8 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcjQbd8',
                         perturbative_expansion = 0)


NPcjQtu1 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcjQtu1',
                         perturbative_expansion = 0)


NPcjQtu8 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcjQtu8',
                         perturbative_expansion = 0)


NPcjtQd1 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcjtQd1',
                         perturbative_expansion = 0)


NPcjtQd8 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcjtQd8',
                         perturbative_expansion = 0)


NPcju1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcju1',
                       perturbative_expansion = 0)


NPcju8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcju8',
                       perturbative_expansion = 0)


NPcjujd1 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcjujd1',
                         perturbative_expansion = 0)


NPcjujd11 = CouplingOrder(expansion_order = 99,
                          hierarchy = 1,
                          name = 'NPcjujd11',
                          perturbative_expansion = 0)


NPcjujd8 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcjujd8',
                         perturbative_expansion = 0)


NPcjujd81 = CouplingOrder(expansion_order = 99,
                          hierarchy = 1,
                          name = 'NPcjujd81',
                          perturbative_expansion = 0)


NPcjuQb1 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcjuQb1',
                         perturbative_expansion = 0)


NPcjuQb8 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcjuQb8',
                         perturbative_expansion = 0)


NPcld = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcld',
                      perturbative_expansion = 0)


NPcle = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcle',
                      perturbative_expansion = 0)


NPclebQ = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPclebQ',
                        perturbative_expansion = 0)


NPcledj = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcledj',
                        perturbative_expansion = 0)


NPcleju1 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcleju1',
                         perturbative_expansion = 0)


NPcleju3 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcleju3',
                         perturbative_expansion = 0)


NPcleQt1 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcleQt1',
                         perturbative_expansion = 0)


NPcleQt3 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcleQt3',
                         perturbative_expansion = 0)


NPclj1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPclj1',
                       perturbative_expansion = 0)


NPclj3 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPclj3',
                       perturbative_expansion = 0)


NPcll = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcll',
                      perturbative_expansion = 0)


NPcll1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcll1',
                       perturbative_expansion = 0)


NPclu = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPclu',
                      perturbative_expansion = 0)


NPcQb1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQb1',
                       perturbative_expansion = 0)


NPcQb8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQb8',
                       perturbative_expansion = 0)


NPcQd1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQd1',
                       perturbative_expansion = 0)


NPcQd8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQd8',
                       perturbative_expansion = 0)


NPcQe = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcQe',
                      perturbative_expansion = 0)


NPcQj11 = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcQj11',
                        perturbative_expansion = 0)


NPcQj18 = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcQj18',
                        perturbative_expansion = 0)


NPcQj31 = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcQj31',
                        perturbative_expansion = 0)


NPcQj38 = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcQj38',
                        perturbative_expansion = 0)


NPcQl1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQl1',
                       perturbative_expansion = 0)


NPcQl3 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQl3',
                       perturbative_expansion = 0)


NPcQQ1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQQ1',
                       perturbative_expansion = 0)


NPcQQ8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQQ8',
                       perturbative_expansion = 0)


NPcQt1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQt1',
                       perturbative_expansion = 0)


NPcQt8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQt8',
                       perturbative_expansion = 0)


NPcQtjd1 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcQtjd1',
                         perturbative_expansion = 0)


NPcQtjd8 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcQtjd8',
                         perturbative_expansion = 0)


NPcQtQb1 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcQtQb1',
                         perturbative_expansion = 0)


NPcQtQb8 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcQtQb8',
                         perturbative_expansion = 0)


NPcQu1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQu1',
                       perturbative_expansion = 0)


NPcQu8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcQu8',
                       perturbative_expansion = 0)


NPcQujb1 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcQujb1',
                         perturbative_expansion = 0)


NPcQujb8 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcQujb8',
                         perturbative_expansion = 0)


NPctB = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPctB',
                      perturbative_expansion = 0)


NPctb1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPctb1',
                       perturbative_expansion = 0)


NPctb8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPctb8',
                       perturbative_expansion = 0)


NPctd1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPctd1',
                       perturbative_expansion = 0)


NPctd8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPctd8',
                       perturbative_expansion = 0)


NPcte = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcte',
                      perturbative_expansion = 0)


NPctG = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPctG',
                      perturbative_expansion = 0)


NPctH = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPctH',
                      perturbative_expansion = 0)


NPctj1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPctj1',
                       perturbative_expansion = 0)


NPctj8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPctj8',
                       perturbative_expansion = 0)


NPctl = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPctl',
                      perturbative_expansion = 0)


NPctt = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPctt',
                      perturbative_expansion = 0)


NPctu1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPctu1',
                       perturbative_expansion = 0)


NPctu8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPctu8',
                       perturbative_expansion = 0)


NPctW = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPctW',
                      perturbative_expansion = 0)


NPcuB = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcuB',
                      perturbative_expansion = 0)


NPcud1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcud1',
                       perturbative_expansion = 0)


NPcud8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcud8',
                       perturbative_expansion = 0)


NPcuG = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcuG',
                      perturbative_expansion = 0)


NPcuH = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcuH',
                      perturbative_expansion = 0)


NPcutbd1 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcutbd1',
                         perturbative_expansion = 0)


NPcutbd8 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPcutbd8',
                         perturbative_expansion = 0)


NPcuu1 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcuu1',
                       perturbative_expansion = 0)


NPcuu8 = CouplingOrder(expansion_order = 99,
                       hierarchy = 1,
                       name = 'NPcuu8',
                       perturbative_expansion = 0)


NPcuW = CouplingOrder(expansion_order = 99,
                      hierarchy = 1,
                      name = 'NPcuW',
                      perturbative_expansion = 0)


NPcW = CouplingOrder(expansion_order = 99,
                     hierarchy = 1,
                     name = 'NPcW',
                     perturbative_expansion = 0)


NPcWtil = CouplingOrder(expansion_order = 99,
                        hierarchy = 1,
                        name = 'NPcWtil',
                        perturbative_expansion = 0)


NPQjujb8 = CouplingOrder(expansion_order = 99,
                         hierarchy = 1,
                         name = 'NPQjujb8',
                         perturbative_expansion = 0)


EFT = CouplingOrder(expansion_order = 99,
                    hierarchy = 1,
                    name = 'EFT',
                    perturbative_expansion = 0)

